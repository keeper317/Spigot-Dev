package mediaapps.LilyPad.util;

import java.util.ArrayList;
import java.util.Arrays;
import mediaapps.LilyPad.MAAPI;
import mediaapps.LilyPad.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

public class ScoreBoardHandler 
{
	public static void scoreBoard1(double[] dis, String input)
	{
		ScoreboardManager manager = Bukkit.getScoreboardManager();
		Scoreboard board = manager.getNewScoreboard();
		Objective obj = board.registerNewObjective("Pos", "dummy");
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
		obj.setDisplayName("LilyPad Jumper");

				for(int a = 0; a < dis.length; a++)
				{	
					String str = "";
					Player p = Main.players.get(a);
					if(p.getName().length() <= 10)
						str = p.getName();
					else
					{
						for(int i = 0; i < 10; i++)
						{
							str += p.getName().charAt(i);
						}
					}
					Score score = obj.getScore(Bukkit.getOfflinePlayer("�a" + (a + 1) + " " + str));
					score.setScore(Main.maxPlayers - a);
					p.setScoreboard(board);
				}		
	}
	public static void statBoard(Player p)
	{
		ScoreboardManager manager = Bukkit.getScoreboardManager();
		Scoreboard board = manager.getNewScoreboard();
		Objective obj = board.registerNewObjective("stats", "dummy");
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
		obj.setDisplayName("LilyPad Jumper Stats");
		Score wins = obj.getScore(Bukkit.getOfflinePlayer("�aWins: "));
		wins.setScore(MAAPI.getWins(p));
		Score money = obj.getScore(Bukkit.getOfflinePlayer("�bTokens: "));
		money.setScore((int) Main.econ.getBalance(p.getName()));
		Score jumps = obj.getScore(Bukkit.getOfflinePlayer("�dJumps: "));
		jumps.setScore(Misc.getJumps(p));
		p.setScoreboard(board);
	}
	public static void clearBoard(Player p)
	{
		ScoreboardManager manager = Bukkit.getScoreboardManager();
		Scoreboard board = manager.getNewScoreboard();
		p.setScoreboard(board);
	}
	public static void getPlaces(ArrayList<Player> p, String str)
	{
		double[] dis = new double[p.size()];
		for(int run = 0; run < p.size(); run++)
			dis[run] = p.get(run).getLocation().distance(Main.spawns[1]);
		Arrays.sort(dis);
		scoreBoard1(dis, str);
	}
}
