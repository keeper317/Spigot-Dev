package mediaapps.LilyPad;

import org.bukkit.configuration.file.FileConfiguration;

public class ConfigSet 
{
	public static void setDefaults(FileConfiguration config)
	{
		config.addDefault("Start", "world:1.0:1.0:1.0");
		config.addDefault("End", "world:1.0:1.0:1.0");
		config.addDefault("Lobby", "world:1.0:1.0:1.0");
		config.addDefault("Lobbye", "world:1.0:1.0:1.0");
		config.addDefault("Fields", "world:1.0:1.0:1.0");
		config.addDefault("Fielde", "world:1.0:1.0:1.0");
		config.addDefault("ObMsg", "Sorry Pal, but you Lose this round!");
	}
}
