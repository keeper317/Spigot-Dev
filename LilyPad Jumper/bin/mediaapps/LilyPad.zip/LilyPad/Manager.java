package mediaapps.LilyPad;

import mediaapps.LilyPad.events.Interaction;
import mediaapps.LilyPad.util.LilyPadSpawns;
import mediaapps.LilyPad.util.Misc;
import mediaapps.LilyPad.util.ScoreBoardHandler;
import mediaapps.LilyPad.util.SpawnHandler;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class Manager 
{
	public static void startGame()
	{
		if(!Main.inProg)
		{
			Main.inProg = true;
			SpawnHandler.teletportToArena();
			
			
			
			Bukkit.broadcastMessage("�A-LilyPad Jumper- \n�bObjective: \n�aSTAY OUT OF THE WATER! \nFirst to the beacon wins \nDon't stay on the lilypad for too long!");
			for( int i = 5; i > 0; i--)
			{
				new BukkitRunnable()
				{
					@Override
					public void run()
					{
						System.out.print("");
					}
				}.runTaskLater(Main.plugin, 20 * 2);
				
				Bukkit.broadcastMessage("�bGame Starting in �a" + i + " seconds");
			}
			Bukkit.broadcastMessage("�4Go!");
			LilyPadSpawns.placeLily();
		}
	}
	
	public static void endGame()
	{
		Main.inProg = false;
		LilyPadSpawns.breakLily();
		SpawnHandler.teleportToLobby();
		Bukkit.broadcastMessage("�AThat's the game!");
		for(int i = 0; i < Main.players.size(); i++)
		{
			Player p = Main.players.get(i);
			Misc.gameEnded(p);
			MAAPI.giveMoney(p);
		}
		for(int i = 0; i < Main.specs.size(); i++)
		{
			Player p = Main.specs.get(i);
			Misc.gameEnded(p);
			MAAPI.giveMoney(p);
		}
		Interaction.sign.setLine(0, "Join Now");
		Interaction.sign.setLine(2, "0/" + Main.maxPlayers);
		Interaction.sign.update();
		ScoreBoardHandler.getPlaces(Main.players, "reset");
		ScoreBoardHandler.getPlaces(Main.specs, "reset");
	}
}