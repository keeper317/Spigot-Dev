package mediaapps.LilyPad.events;

import mediaapps.LilyPad.Main;
import mediaapps.LilyPad.ShopGUI;
import mediaapps.LilyPad.util.Misc;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class ClickEvents implements Listener
{
	@EventHandler
	public void clickedOn(InventoryClickEvent e)
	{
		Player p = (Player) e.getWhoClicked();
		if(e.getInventory().getTitle().equals(ShopGUI.shop.getName()))
		{
				e.setCancelled(true);
				if(Main.econ.getBalance(p.getName()) >= 25)
				{
					p.sendMessage("�3Double Jump Bought!");
				
					Misc.addJumps(p);
					Main.econ.withdrawPlayer(p.getName(), 25);
				}
		}
		
	}
}
