package mediaapps.LilyPad.events;

import mediaapps.LilyPad.MAAPI;
import mediaapps.LilyPad.Main;
import mediaapps.LilyPad.Manager;
import mediaapps.LilyPad.util.Misc;
import mediaapps.LilyPad.util.ScoreBoardHandler;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class Movements implements Listener
{
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onPlayerMoveEvent(PlayerMoveEvent e)
	{
		final Player p = e.getPlayer();
		Location l = p.getLocation();
		
		final Location below = p.getLocation();
		if(Main.inProg)
		{
			new BukkitRunnable()
			{
				@Override
				public void run()
				{
					Misc.setBlockAir(below.getBlockX(), below.getBlockZ(), p.getWorld());
				}
			}.runTaskLater(Main.plugin, 20);
			if(l.distance(Main.spawns[1]) < 1)
			{
				MAAPI.addPoints(p, 15);
				MAAPI.addWin(p);
				Bukkit.broadcastMessage("�3" + p.getName() + " Has won by reaching the end");
				Manager.endGame();
			}
			if(l.getY() < Main.field[0].getY() && Main.inProg && Main.players.contains(p))
			{
				Misc.addSpecs(p);
				Bukkit.broadcastMessage("�c" + p.getName() + " Has drowned like an idiot. \nHasn't anyone told him this is easy?"); 
			}
			ScoreBoardHandler.getPlaces(Main.players, "");
			ScoreBoardHandler.getPlaces(Main.specs, ""); 
		}
		if(p.getLocation().distance(Main.spawns[2]) <= 5)
				ScoreBoardHandler.statBoard(p);
		else if(p.getLocation().distance(Main.spawns[2]) > 5)
			ScoreBoardHandler.clearBoard(p);
	}
}