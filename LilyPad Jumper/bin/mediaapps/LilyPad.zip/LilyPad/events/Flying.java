package mediaapps.LilyPad.events;

import mediaapps.LilyPad.Main;
import mediaapps.LilyPad.util.Misc;

import org.bukkit.util.Vector;

import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleFlightEvent;

public class Flying implements Listener 
{
	@EventHandler
	public void onFlightAttempt(PlayerToggleFlightEvent e) 
	{
	    if(e.isFlying() && e.getPlayer().getGameMode() != GameMode.CREATIVE) 
	    {
	    	if(Misc.getJumps(e.getPlayer()) > 0)
	    	{
	    		e.getPlayer().setVelocity(e.getPlayer().getVelocity().add(new Vector(0,.85,0)));
	    		Main.jumps.put(e.getPlayer().getName(), Main.jumps.get(e.getPlayer().getName()) - 1);
	    	}
	    	else
	    	{
	    		e.getPlayer().sendMessage("�cYou do not have any more double jumps!");
	    	}
	        e.setCancelled(true);
	        e.getPlayer().setFlying(false);
	    }
	}
}
