package mediaapps.LilyPad.events;

import mediaapps.LilyPad.Main;
import mediaapps.LilyPad.Manager;
import mediaapps.LilyPad.util.Misc;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PlayerJoin
{
	public static void Joined(Player p)
	{
		if(!Main.players.contains(p))
		{
			if(Main.inProg)
			{
				Misc.addSpecs(p);
				p.sendMessage("�cYou have joined an inprog game.\nThe game will end soon.");
			}
			else if(!Main.inProg)
			{
				Misc.addPlayers(p);
				p.sendMessage("�1You have joined the game");
				if(Main.players.size() >= Main.maxPlayers)
					Manager.startGame();
			}
			Bukkit.broadcastMessage(p.getName() + " Has joined the game");
		}
		else if(Main.players.contains(p))
			p.sendMessage("�CYou are already in the game!");
	}
}
