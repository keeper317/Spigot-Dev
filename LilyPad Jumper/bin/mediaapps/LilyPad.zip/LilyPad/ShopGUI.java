package mediaapps.LilyPad;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ShopGUI 
{
	public static Inventory shop;
	
	public static void shopGui()
	{
		shop = Bukkit.getServer().createInventory(null, 9, "LilyPad Shop");
		ItemStack stack = new ItemStack(Material.WATER_LILY);
		ItemMeta meta = stack.getItemMeta();
		List<String> lore = new ArrayList<String>();
		lore.add("�5Click me to buy a double jump!");
		lore.add("�3One time use!");
		lore.add("�aCost: 25 tokens");
		lore.add("�c�n�lWill be lost to Server reload");
		meta.setDisplayName("Double Jumps");
		meta.setLore(lore);
		stack.setItemMeta(meta);
		shop.setItem(4, stack);
	}
}
